
import React, { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { motion } from "framer-motion";
import "./App.css";

export default function SavingsCRMApp() {
  const [monthlyIncome, setMonthlyIncome] = useState(() => Number(localStorage.getItem("monthlyIncome")) || 4000);
  const [fixedExpenses, setFixedExpenses] = useState(() => JSON.parse(localStorage.getItem("fixedExpenses")) || []);
  const [annualFees, setAnnualFees] = useState(() => JSON.parse(localStorage.getItem("annualFees")) || Array.from({ length: 10 }, (_, i) => ({ id: i + 1, name: `Opłata roczna ${i + 1}`, amount: 0 })));
  const [buckets, setBuckets] = useState(() => JSON.parse(localStorage.getItem("buckets")) || { cash: { amount: 1000 }, metals: { gold: 0, silver: 0 }, stocks: { amount: 2000, annualContribution: 200, annualGrowthPct: 6 } });
  const [years, setYears] = useState(() => Number(localStorage.getItem("projectionYears")) || 10);
  const [goals, setGoals] = useState(() => JSON.parse(localStorage.getItem("goals")) || []);
  const [calendarEvents, setCalendarEvents] = useState([]);

  useEffect(() => {
    localStorage.setItem("monthlyIncome", monthlyIncome);
    localStorage.setItem("fixedExpenses", JSON.stringify(fixedExpenses));
    localStorage.setItem("annualFees", JSON.stringify(annualFees));
    localStorage.setItem("buckets", JSON.stringify(buckets));
    localStorage.setItem("projectionYears", years);
    localStorage.setItem("goals", JSON.stringify(goals));
  }, [monthlyIncome, fixedExpenses, annualFees, buckets, years, goals]);

  const calculateMonthlyFixedTotal = () => fixedExpenses.reduce((s, e) => s + Number(e.amount || 0), 0);
  const calculateAnnualFeesTotalMonthlyEquivalent = () => annualFees.reduce((s, f) => s + Number(f.amount || 0), 0) / 12;
  const calculateFreeCashflow = () => monthlyIncome - calculateMonthlyFixedTotal() - calculateAnnualFeesTotalMonthlyEquivalent();

  const projectStocks = ({ principal, contribution, ratePct, years }) => {
    let series = [], value = principal, rate = ratePct / 100;
    for (let y = 0; y <= years; y++) {
      series.push({ year: y, value: Math.round(value) });
      value = value * (1 + rate) + contribution;
    }
    return series;
  };

  const advancedInvestmentSimulation = () => {
    let conservative = projectStocks({ principal: buckets.stocks.amount, contribution: buckets.stocks.annualContribution, ratePct: 4, years });
    let moderate = projectStocks({ principal: buckets.stocks.amount, contribution: buckets.stocks.annualContribution, ratePct: 6, years });
    let aggressive = projectStocks({ principal: buckets.stocks.amount, contribution: buckets.stocks.annualContribution, ratePct: 10, years });
    return { conservative, moderate, aggressive };
  };

  const analyzeExpenses = () => {
    const monthlyFixed = calculateMonthlyFixedTotal();
    const monthlyAnnualEq = calculateAnnualFeesTotalMonthlyEquivalent();
    const suggestions = [];
    if (monthlyFixed > monthlyIncome * 0.5) suggestions.push("Stałe wydatki przekraczają 50% dochodu — rozważ renegocjację czynszu lub zmianę dostawców usług.");
    if (monthlyAnnualEq > monthlyIncome * 0.2) suggestions.push("Opłaty roczne są wysokie — sprawdź, które z nich można ograniczyć lub rozłożyć na raty.");
    return suggestions;
  };

  const freeCashflow = calculateFreeCashflow();
  const projection = projectStocks({ principal: buckets.stocks.amount, contribution: buckets.stocks.annualContribution, ratePct: buckets.stocks.annualGrowthPct, years });
  const investmentScenarios = advancedInvestmentSimulation();
  const expenseAnalysis = analyzeExpenses();

  return (
    <div className="p-4 bg-gray-50 min-h-screen">
      <h1 className="text-2xl font-bold mb-4">Plan oszczędzania — CRM</h1>
      <div className="mb-4">Wolne środki: {Math.round(freeCashflow)} PLN / mies.</div>

      <div className="bg-white rounded-xl shadow p-4 mb-4">
        <h2 className="font-semibold mb-2">Analiza wydatków</h2>
        {expenseAnalysis.length === 0 ? <div>Brak sugestii — Twoje wydatki są pod kontrolą.</div> : (
          <ul className="list-disc pl-4">
            {expenseAnalysis.map((s, i) => <li key={i}>{s}</li>)}
          </ul>
        )}
      </div>

      <div className="bg-white rounded-xl shadow p-4 mb-4">
        <h2 className="font-semibold mb-2">Symulacja inwestycji</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div><strong>Konserwatywna:</strong> {investmentScenarios.conservative[years].value} PLN</div>
          <div><strong>Umiarkowana:</strong> {investmentScenarios.moderate[years].value} PLN</div>
          <div><strong>Agresywna:</strong> {investmentScenarios.aggressive[years].value} PLN</div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow p-4 mb-4">
        <h2 className="font-semibold mb-2">Integracja z kalendarzem</h2>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded" onClick={() => alert("Wysyłanie wydarzeń do kalendarza Google — demo")}>Eksportuj wydarzenia</button>
      </div>
    </div>
  );
}
